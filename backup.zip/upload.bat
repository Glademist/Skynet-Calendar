@echo off
echo Uploading build/ to server...
scp -r build\. sasa@91.99.216.84:/var/www/skynet/
if %ERRORLEVEL% NEQ 0 (
    echo Upload failed!
) else (
    echo Upload finished.
)